"""
ShellMind - AI-powered terminal assistant
"""
__version__ = "0.1.0"
